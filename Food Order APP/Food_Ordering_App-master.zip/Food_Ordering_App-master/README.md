# Food_Ordering_App

[This is How Final app will look !](https://www.youtube.com/watch?v=iNe31x-oNiM)

tested on API 27, redminote4

● Used Firebase to store restaurant data, Applied MVC pattern design style for client side & server side.

● Provided sign in/sign up function, menu and food list loading, orders management process, and intro sliders for new users.

<h5>As I am a android learner myself, all help & contribution is very well appreciated. If you find this idea or the underlying code useful, feel free to reuse it in your own projects.</h5>

![Firebase Structure](https://user-images.githubusercontent.com/31734493/67163008-c0113b00-f387-11e9-8e4f-a43a85ca8bed.png)

<img src="https://user-images.githubusercontent.com/31734493/67163069-4d548f80-f388-11e9-9f0f-c18d2ac90744.png" width="200" height="400" />)
