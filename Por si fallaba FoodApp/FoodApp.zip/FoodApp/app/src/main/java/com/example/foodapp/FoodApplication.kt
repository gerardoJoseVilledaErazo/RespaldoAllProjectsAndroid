package com.example.foodapp

import android.app.Application

class FoodApplication : Application() {
}