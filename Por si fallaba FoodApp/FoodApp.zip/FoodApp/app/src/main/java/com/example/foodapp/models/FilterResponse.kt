package com.example.foodapp.models

data class FilterResponse(
    val meals: List<Meal>?
)