package com.example.foodapp.models

data class RecipeResponse(
    val meals: List<Meal>?
)