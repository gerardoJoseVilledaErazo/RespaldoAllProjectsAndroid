package com.example.foodapp.util

class Constants {
    companion object {
        const val GRID_LAYOUT_SPAN_COUNT = 2
        const val BASE_URL = "https://www.themealdb.com"
        const val SEARCH_DELAY = 500L
    }
}