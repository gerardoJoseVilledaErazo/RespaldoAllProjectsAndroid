package com.example.foodapp.models

data class CategoriesResponse(
    val categories: List<Category>
)