package chellotech.br.agendatelefonica.model

class Pessoa(
    var id:Int,
    var nome:String,
    var endereco:String,
    var numero:Int,
    var bairro:String,
    var email:String,
    var telefone:String
)
