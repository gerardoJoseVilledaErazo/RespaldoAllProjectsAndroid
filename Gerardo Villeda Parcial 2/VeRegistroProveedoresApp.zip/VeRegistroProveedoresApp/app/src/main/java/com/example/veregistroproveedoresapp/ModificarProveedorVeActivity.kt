package com.example.veregistroproveedoresapp

import android.content.DialogInterface
import android.content.Intent
import android.content.pm.ActivityInfo
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.example.veregistroproveedoresapp.Model.ProveedorVe
import java.util.regex.Pattern

class ModificarProveedorVeActivity : AppCompatActivity(), View.OnClickListener {
    private lateinit var proveedorVe: ProveedorVe

    // Declaración de componentes necesarios
    private lateinit var et_update_id: EditText
    private lateinit var et_update_name: EditText
    private lateinit var et_update_nit: EditText
    private lateinit var et_update_tipo_proveedor: EditText
    private lateinit var btn_update: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_modificar_proveedor_ve)

        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT

        //Enlazar componentes desde la lógica con la vista
        et_update_id = findViewById(R.id.et_update_id);
        et_update_name = findViewById(R.id.et_update_name);
        et_update_nit = findViewById(R.id.et_update_nit)
        et_update_tipo_proveedor = findViewById(R.id.et_update_tipo_proveedor)

        btn_update = findViewById(R.id.btnUpdate)
        btn_update.setOnClickListener(this)

        proveedorVe = (intent.getSerializableExtra("proveedor") as ProveedorVe?)!!

        et_update_id.setText(proveedorVe.id)
        et_update_name.setText(proveedorVe.nombre)
        et_update_nit.setText(proveedorVe.nit)
        et_update_tipo_proveedor.setText(proveedorVe.tipo_proveedor)
    }

    override fun onClick(p0: View?) {
        when(p0!!.id){
            R.id.btnUpdate -> {
                // Se valida que todos los campos tengan valores y que el nombre no tenga numeros, solo letras
                if (verifyEmpty(et_update_id)
                    && verifyTextPersonName(et_update_name)
                    && verifyEmpty(et_update_nit)
                    && verifyEmpty(et_update_tipo_proveedor)
                )
                {/// estado ==1: update, es para actualizar o modificar
                    // Se actualiza el registro en la lista

                    guardarRegistro(et_update_id.text.toString().toInt()
                        ,et_update_name.text.toString()
                        ,et_update_nit.text.toString()
                        ,et_update_tipo_proveedor.text.toString())

                    AlertDialog.Builder(this)
                        .setTitle("Confirmacion")
                        .setMessage("Desea continuar")
                        .setPositiveButton("Aceptar")
                        { dialogInterface: DialogInterface?, i1: Int ->

                            // Llamado al dialog
                            configProgressDialog()
                            // Permite ir a la vista para mostrar la lista de clientes
                            startActivity(
                                Intent(this, VEMainActivity::class.java)
                            )
                            Toast.makeText(this.applicationContext, "Modificado.", Toast.LENGTH_SHORT).show();
                        }
                        .setNegativeButton("Cancelar", null)
                        .show()

                }
            }
        }
    }

    // Metodo que permite guardar un registro
    private fun guardarRegistro(id: Int, nombre: String, nit: String, tipo_proveedor: String)
    {
        val proveedorVe = ProveedorVe(id, nombre, nit, tipo_proveedor)
        // Se hace el import de la lista declarada en el VEMainActivity.kt
        // y se añaden registros
        VEMainActivity.lstProveedores.add(proveedorVe)
    }


    private fun verifyTextPersonName(editText: EditText): Boolean {
        if (editText.text.toString().isEmpty()){
            editText.error = "Required field"
            editText.requestFocus()
            return false
        } else if (!verifyChars(editText)) {
            editText.error = "Just letters are allowed"
            editText.requestFocus()
            return false
        }
        return true

    }

    fun verifyChars(editText: EditText): Boolean
    {
        //Validamos solo caracteres Expresion regular
//        Pattern.compile("^[a-zA-Z ]+$").matcher(editText.text.toString()).matches()

        return Pattern.compile("^[a-zA-Z ]+$").matcher(editText.text.toString()).matches()
    }
    fun verifyEmpty(editText: EditText): Boolean
    {
        if (editText.text.toString().isEmpty()){
            editText.error = "Required field"
            editText.requestFocus()
            return false
        }
        return true
    }
    // Configurador del progress dialog
    fun configProgressDialog(){
        val alertBuilder: AlertDialog.Builder = AlertDialog.Builder(this)
        val dialogView = layoutInflater.inflate(R.layout.progress_dialog,
            null)
        alertBuilder.setView(dialogView)
        alertBuilder.setCancelable(false)
        val dialog = alertBuilder.create()
        dialog.show()
        // Configurando hilo, para asignar tiempo
        Handler(Looper.getMainLooper()).postDelayed({
            dialog.dismiss()
            finish()
        }, 3000)
    }
}