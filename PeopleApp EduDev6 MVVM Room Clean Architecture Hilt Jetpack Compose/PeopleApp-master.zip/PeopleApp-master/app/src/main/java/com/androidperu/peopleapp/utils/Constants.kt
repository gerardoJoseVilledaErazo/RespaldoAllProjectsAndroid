package com.androidperu.peopleapp.utils

const val DATABASE_NAME = "user_db"