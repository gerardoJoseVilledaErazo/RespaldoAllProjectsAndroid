package com.androidperu.peopleapp.feature_users.presentation.edit

data class TextFieldState(
    val text: String = ""
)
