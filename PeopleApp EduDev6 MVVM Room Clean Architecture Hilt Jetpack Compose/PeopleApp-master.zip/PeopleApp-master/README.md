# PeopleApp
PeopleApp is an application where you see the CRUD with the use of the Room database. You can delete, edit, create, and search for a user's data. The project uses Coroutines, Navigation, MVVM, Jetpack Compose and more


[![App1-preview-rev-1.png](https://i.postimg.cc/BvGTDw0k/App1-preview-rev-1.png)](https://postimg.cc/68Y4xcTf)
