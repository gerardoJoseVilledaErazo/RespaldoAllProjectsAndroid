package com.example.veregistroproveedoresapp.Model

data class ProveedorVe(var id: Int, var nombre: String, var nit: String, var tipo_proveedor: String) {
}