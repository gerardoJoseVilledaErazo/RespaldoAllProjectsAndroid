package com.example.veregistroproveedoresapp

import android.content.DialogInterface
import android.content.Intent
import android.content.pm.ActivityInfo
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import com.example.veregistroproveedoresapp.Model.ProveedorVe
import com.example.veregistroproveedoresapp.VEMainActivity.Companion.lstProveedores
import java.util.regex.Pattern

class AgregarProveedorVeActivity : AppCompatActivity(), View.OnClickListener {

    // Declaración de componentes necesarios
    private lateinit var et_id: EditText
    private lateinit var et_nombre: EditText
    private lateinit var et_nit: EditText
    private lateinit var et_tipo_proveedor: EditText
    private lateinit var btnRegistrar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_agregar_proveedor_ve)

        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT

        // Se agrega la flecha para salir de la actividad
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        // Se configura el nombre de la actividad
        title = "Agregar Proveedor"

        //Enlazar componentes desde la lógica con la vista
        et_id = findViewById(R.id.et_id);
        et_nombre = findViewById(R.id.et_nombre);
        et_nit = findViewById(R.id.et_nit)
        et_tipo_proveedor = findViewById(R.id.et_tipo_proveedor)

        btnRegistrar = findViewById(R.id.btnRegistrar)

        // Se configura el oyente del boton registrar
        btnRegistrar.setOnClickListener(this)
    }

    override fun onClick(p0: View?) {
        when(p0!!.id){
            R.id.btnRegistrar -> {
                // Se valida que todos los campos tengan valores y que el nombre no tenga numeros, solo letras
                if (verifyEmpty(et_id)
                    && verifyTextPersonName(et_nombre)
                    && verifyEmpty(et_nit)
                    && verifyEmpty(et_tipo_proveedor)
                )
                {
                    // Se guarda el registro en la lista
                    guardarRegistro(et_id.text.toString().toInt()
                        ,et_nombre.text.toString()
                        ,et_nit.text.toString()
                        ,et_tipo_proveedor.text.toString())
                    // Se muestra un dialog indicando que el registro fué exitoso
                    AlertDialog.Builder(this).setTitle("¡Registro Exitoso!")
                        .setMessage("El registro se guardo con éxito")
                        .setPositiveButton("Ok", DialogInterface.OnClickListener
                        { dialogInterface, i ->
                            startActivity(
                                Intent(this,
                                    VEMainActivity::class.java)
                            )
                        }).show()
                }
            }
        }
    }

    // Metodo que permite guardar un registro
    private fun guardarRegistro(id: Int, nombre: String, nit: String, tipo_proveedor: String)
    {
        val proveedorVe = ProveedorVe(id, nombre, nit, tipo_proveedor)
        // Se hace el import de la lista declarada en el VEMainActivity.kt
        // y se añaden registros
        lstProveedores.add(proveedorVe)
    }


    private fun verifyTextPersonName(editText: EditText): Boolean {
        if (editText.text.toString().isEmpty()){
            editText.error = "Required field"
            editText.requestFocus()
            return false
        } else if (!verifyChars(editText)) {
            editText.error = "Just letters are allowed"
            editText.requestFocus()
            return false
        }
        return true

    }

    fun verifyChars(editText: EditText): Boolean
    {
        //Validamos solo caracteres Expresion regular
//        Pattern.compile("^[a-zA-Z ]+$").matcher(editText.text.toString()).matches()

        return Pattern.compile("^[a-zA-Z ]+$").matcher(editText.text.toString()).matches()
    }
    fun verifyEmpty(editText: EditText): Boolean
    {
        if (editText.text.toString().isEmpty()){
            editText.error = "Required field"
            editText.requestFocus()
            return false
        }
        return true
    }

    // Se configura la flecha para salir de la actividad
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            android.R.id.home -> {
                // Finalizar la actividad
                finish()
            }
        }
        return super.onOptionsItemSelected(item)
    }
}