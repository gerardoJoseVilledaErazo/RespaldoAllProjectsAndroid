package com.example.veregistroproveedoresapp.Interface

import com.example.veregistroproveedoresapp.Model.ProveedorVe

interface ItemClickListener {
    fun OnItemClick(position: Int, proveedorVe: ProveedorVe?)
}