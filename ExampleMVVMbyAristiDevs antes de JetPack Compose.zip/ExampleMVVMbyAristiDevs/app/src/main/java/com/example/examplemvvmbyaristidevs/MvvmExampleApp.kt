package com.example.examplemvvmbyaristidevs

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MvvmExampleApp : Application()