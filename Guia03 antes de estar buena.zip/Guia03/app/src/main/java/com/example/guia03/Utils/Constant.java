package com.example.guia03.Utils;

public final class Constant {

   public static final int cotizacion_limite_isss = 30;
   public static final float cotizacion_limite_afp = 510.76f;
}
