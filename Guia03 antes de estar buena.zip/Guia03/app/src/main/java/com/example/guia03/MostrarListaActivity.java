package com.example.guia03;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import static com.example.guia03.TrabajadorTiempoCompletoActivity.trabajadorRepositoryTC;
import static com.example.guia03.TrabajadorHoraActivity.trabajadorRepositoryTH;

import com.example.guia03.Model.TrabajadorHoraModel;
import com.example.guia03.Model.TrabajadorTiempoCompletoModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MostrarListaActivity extends AppCompatActivity {

    FloatingActionButton btnNuevoTrabajador;

    private ListView lstVistaTrabajadores;
    private ListView lstVistaTrabajadoresTH;
    private ListView lstVistaTrabajadoresTC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostrar_lista);
        if ( getSupportActionBar() != null ) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        this.btnNuevoTrabajador =(FloatingActionButton)findViewById(R.id.btnNuevoTrabajador);

        this.lstVistaTrabajadoresTC = (ListView) findViewById(R.id.lsvTrabajadorTC);
        this.lstVistaTrabajadoresTH = (ListView) findViewById(R.id.lsvTrabajadorTH);

        ArrayAdapter<TrabajadorTiempoCompletoModel> adTC = new ArrayAdapter(MostrarListaActivity.this, android.R.layout.simple_list_item_1,trabajadorRepositoryTC);
        ArrayAdapter<TrabajadorHoraModel> adTH = new ArrayAdapter(MostrarListaActivity.this, android.R.layout.simple_list_item_1,trabajadorRepositoryTH);
        lstVistaTrabajadoresTH.setAdapter(adTH);
        lstVistaTrabajadoresTC.setAdapter(adTC);
//        Utility.setListViewHeightBasedOnChildren(lstVistaTrabajadoresTH);
//        Utility.setListViewHeightBasedOnChildren(lstVistaTrabajadoresTC);
//        adTC.notifyDataSetChanged();
//        adTH.notifyDataSetChanged();


        // Eventos
        this.btnNuevoTrabajador.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MostrarListaActivity.this, SeleccionarTrabajadorActivity.class));
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home: {
                finish();
            }break;
        }
        return true;
    }
}