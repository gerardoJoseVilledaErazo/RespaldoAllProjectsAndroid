package com.example.sampleui.ui.search

import javax.inject.Inject

/**
 *SampleUI
 *@author Anjali Yadav
 *@date 08/04/2022 10:00 PM
 */
class SearchRepos @Inject constructor() {
}