package com.example.sampleui.ui.checkout

import androidx.lifecycle.ViewModel
import javax.inject.Inject

/**
 *SampleUI
 *@author Anjali Yadav
 *@date 08/04/2022 12:57 AM
 */
class CheckoutViewModel @Inject constructor(
    private val repose: CheckoutRepos,
) : ViewModel() {
}