package com.example.sampleui.ui.accounts

import javax.inject.Inject

/**
 *SampleUI
 *@author Anjali Yadav
 *@date 08/04/2022 9:57 PM
 */
class AccountRepos @Inject constructor(){
}