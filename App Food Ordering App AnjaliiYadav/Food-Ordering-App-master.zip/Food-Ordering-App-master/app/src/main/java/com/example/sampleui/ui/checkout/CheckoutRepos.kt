package com.example.sampleui.ui.checkout

import javax.inject.Inject

/**
 *SampleUI
 *@author Anjali Yadav
 *@date 08/04/2022 2:57 PM
 */
class CheckoutRepos @Inject constructor() {
}