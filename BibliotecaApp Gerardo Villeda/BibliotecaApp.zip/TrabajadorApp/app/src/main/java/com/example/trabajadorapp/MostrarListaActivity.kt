package com.example.trabajadorapp

import android.content.Context
import android.content.DialogInterface
import android.graphics.Color
import android.net.ConnectivityManager
import android.os.Bundle
import android.view.MenuItem
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener
import com.example.trabajadorapp.Adapters.PublicacionAdapter
import com.example.trabajadorapp.MainActivity.Companion.publicacionRepository
import com.example.trabajadorapp.databinding.ActivityMostrarListaBinding


class MostrarListaActivity : AppCompatActivity() {

    // Variable para configurar viewBinding
    private lateinit var binding: ActivityMostrarListaBinding

    // Variables necesarias para configurar el recyclerview
    private lateinit var recyclerView: RecyclerView

    lateinit var swipeRefreshLayout: SwipeRefreshLayout

    private lateinit var publicacionAdapter: PublicacionAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Configuracion de viewBinding
        binding = ActivityMostrarListaBinding.inflate(layoutInflater)

        setContentView(binding.root)

        // Habilitar action bar
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        swipeRefreshLayout = findViewById(R.id.refreshLayout)

//        swipeRefreshLayout.setOnRefreshListener(OnRefreshListener {
//            swipeRefreshLayout.setRefreshing(false)
//            //your code on swipe refresh
//            //we are checking networking connectivity
//            val connection = isNetworkAvailable()
//            if (connection) {
//
//            } else {
//            }
//        })
//        swipeRefreshLayout.setColorSchemeColors(Color.CYAN)

        // Validar si la lista esta vacia
        if(publicacionRepository.get().size == 0){
            AlertDialog.Builder(this)

                .setTitle(this.resources.getString(R.string.titulo_lista_vacia))

                .setMessage(this.resources.getString(R.string.msg_lista_vacia))
                .setPositiveButton(android.R.string.ok,
                    DialogInterface.OnClickListener
                    { dialogInterface, i ->
                        finish()
                    }).show()
        } else {
            // Configurar RecyclerView
            swipeRefreshLayout.setOnRefreshListener(OnRefreshListener {
                swipeRefreshLayout.setRefreshing(false)
                //your code on swipe refresh
                //we are checking networking connectivity
                val connection = isNetworkAvailable()
                if (connection) {

                    // Configurar RecyclerView
                    configRecyclerView()

                } else {
                }
            })
            swipeRefreshLayout.setColorSchemeColors(Color.CYAN)
            // Configurar RecyclerView
            configRecyclerView()
        }
        //configRecyclerView()
    }

    // Método que configura el recyclerview
    private fun configRecyclerView(){
        recyclerView = binding.rcPublicaciones
        recyclerView.setHasFixedSize(true)
        recyclerView.layoutManager = LinearLayoutManager(this)
        publicacionAdapter = PublicacionAdapter(publicacionRepository.get(),
            this)
        recyclerView.adapter = publicacionAdapter
    }

    fun isNetworkAvailable(): Boolean {
        val connectivityManager = this.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return connectivityManager.activeNetworkInfo != null
    }

    // Método que configura el action bar
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            android.R.id.home -> {
                // Finaliza la actividad
                finish()
            }
        }
        return super.onOptionsItemSelected(item)
    }
}