package com.mouredev.pokemonjetpackcompose.ui.theme

import androidx.compose.ui.graphics.Color

val LightGray = Color.LightGray