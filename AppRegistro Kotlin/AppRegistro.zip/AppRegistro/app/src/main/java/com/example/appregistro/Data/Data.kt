package com.example.appregistro.Data

import com.example.appregistro.model.Persona

class Data {

    //static
    companion object{
        var lista_personas=ArrayList<Persona>()
    }
}