package com.example.appregistro.model

class Persona {

    var id:Int=0
        get() {
           return field
        }
        set(value) {
            field=value
        }
     var nombre:String=""
         get() {
            return field
         }
         set(value) {
             field=value
         }
    var direccion:String=""
        get() {
            return field
        }
        set(value) {
            field=value
        }
}