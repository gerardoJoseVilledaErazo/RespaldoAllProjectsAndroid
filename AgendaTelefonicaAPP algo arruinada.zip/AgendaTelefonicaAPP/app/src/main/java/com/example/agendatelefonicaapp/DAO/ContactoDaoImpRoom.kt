package com.example.agendatelefonicaapp.DAO

import android.content.Context
import androidx.room.Room
import com.example.agendatelefonicaapp.DataBase.ContactoDataBase
import com.example.agendatelefonicaapp.Models.Contacto

class ContactoDaoImpRoom (context: Context) : ContactoDAO
{
    val contactoDataBase = Room.databaseBuilder(context,ContactoDataBase::class.java,"contacto.db").allowMainThreadQueries().build()
    val contactoDao: ContactoDAO = contactoDataBase.contactoDao()

    override fun getAll(): MutableList<Contacto> = contactoDao.getAll()

    override fun get(id: Int): Contacto = contactoDao.get(id)

    override fun save(entity: Contacto) {
        contactoDao.save(entity)
    }

    override fun delete(entity: Contacto) {
        contactoDao.delete(entity)
    }

    override fun update(entity: Contacto) {
        contactoDao.update(entity)
    }
}