package com.example.agendatelefonicaapp.Models

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import org.jetbrains.annotations.NotNull
import java.io.Serializable

//@Entity(tableName = "contactos")
@Entity(tableName = "contacto")
data class Contacto (
    @PrimaryKey(autoGenerate = true)
    var id:Int = 0,
//    @NotNull
//    @ColumnInfo(name = "contactoId")

    @ColumnInfo(name = "nombreContacto")
    var nombreContacto:String,

    @ColumnInfo(name = "numeroTelefonico")
    var numeroTelefonico:String,

    @ColumnInfo(name = "propietario")
    var propietario:String
) : Serializable