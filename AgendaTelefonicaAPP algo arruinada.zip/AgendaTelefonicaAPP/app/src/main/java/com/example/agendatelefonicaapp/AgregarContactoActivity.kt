package com.example.agendatelefonicaapp

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.agendatelefonicaapp.DAO.ContactoDAO
import com.example.agendatelefonicaapp.DAO.ContactoDaoImpRoom
import com.example.agendatelefonicaapp.DataBase.ContactoDataBase
import com.example.agendatelefonicaapp.Models.Contacto
import com.google.android.material.textfield.TextInputLayout
import java.util.regex.Pattern

class AgregarContactoActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var contactoDAO: ContactoDAO

    private lateinit var contacto: Contacto

    private lateinit var txtNewContact: TextView

//    Contact Name
    private lateinit var contact_name_edit_text: EditText
    private lateinit var contact_name_text_input_layout: TextInputLayout

    //    Contact phone Number
    private lateinit var contact_phone_edit_text: EditText
    private lateinit var contact_phone_text_input_layout: TextInputLayout

//    botones
    private lateinit var btnGuardarContacto: Button
    private lateinit var btnCancelarContacto: Button

    private var estado: Int = 0/////// se hizo private

    //SharedPreferences
    private lateinit var sharedPreferences: SharedPreferences
    private var NAME_FILE:String="configuration"////// se hizo private
    private lateinit var user:String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_agregar_contacto)

        // Se agrega la flecha para salir de la actividad
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Se configura el nombre de la actividad
        title = "Agregar Contacto"

//        contactoDAO = ContactoDaoImpRoom(this.applicationContext)

        //Enlazar componentes desde la lógica con la vista
        contact_name_edit_text = findViewById(R.id.contact_name_edit_text)
        contact_phone_edit_text = findViewById(R.id.contact_phone_edit_text)

        contact_name_text_input_layout = findViewById(R.id.contact_name_text_input_layout)
        contact_phone_text_input_layout = findViewById(R.id.contact_phone_text_input_layout)

        txtNewContact=findViewById(R.id.txtNewContact)

        btnGuardarContacto=findViewById(R.id.btnGuardarContacto)
        btnCancelarContacto=findViewById(R.id.btnCancelarContacto)

        sharedPreferences = getSharedPreferences(NAME_FILE, MODE_PRIVATE)
        user = sharedPreferences.getString("USER","").toString()

        cargarVE()

        // Llamado al procedimiento que configura los botones
        configuracionBotones()
    }

    // Método que permite configurar los botones
    fun configuracionBotones() {
        btnGuardarContacto.setOnClickListener(this)
        btnCancelarContacto.setOnClickListener(this)
    }

    override fun onClick(p0: View?) {
        when(p0!!.id){
            R.id.btnGuardarContacto->{
                // Se valida que todos los campos tengan valores
                if (verifyTextPersonName(contact_name_edit_text) && verifyEmpty(contact_phone_edit_text))
                {
                    if(estado == 0){
                        // Se guarda el registro en la lista
                        guardarVE();
                        Toast.makeText(this.applicationContext, "Saved.", Toast.LENGTH_SHORT).show();
                    }else{ /// estado ==1: update, es para actualizar o modificar
                        // Se actualiza el registro en la lista
                        actualizarVE();
                        Toast.makeText(this.applicationContext, "Updated.", Toast.LENGTH_SHORT).show();
                    }
                    resetVE()
                    //se cierra la activity y se redirecciona a la vista del listado de contactos
                    startActivity(Intent(this.applicationContext, MostrarListaContactoActivity::class.java))
                }
            }
            R.id.btnCancelarContacto->{
                //Al dar clic en el botón “Cancelar”
                // debe borrar el texto o valor de todos los componentes.
                resetVE()}
        }
    }

//    // Metodo que permite guardar un registro
//    private fun guardarVE() {
//        val nombre = contact_name_edit_text.text.toString()
//        val numero = contact_phone_edit_text.text.toString()
//        val propietario = user
//        contacto = Contacto(nombreContacto = nombre, numeroTelefonico = numero, propietario = propietario)
//
//        contactoDaoVE = ContactoDaoImpRoom(this.applicationContext)
//        contactoDaoVE.save(contacto)
////        (contactoDaoVE as ContactoDaoImpRoom).save(contacto)
//    }

    // Metodo que permite guardar un registro
    private fun guardarVE() {
        val nombre = contact_name_edit_text.text.toString()
        val numero = contact_phone_edit_text.text.toString()
        val propietario = user
        contacto = Contacto(nombreContacto = nombre, numeroTelefonico = numero, propietario = propietario)

//        contactoDAO.save(contacto)
//        ContactoDaoImpRoom(this.applicationContext).save(contacto)

//        val contactoDataBase = ContactoDataBase.getContactDatabase(this)
//        contactoDataBase?.contactoDao()?.save(contacto)

//        contactoList.add(contacto) //// lo mas cerca que he llegado

    }

    // Metodo que permite actualizar un registro
    private fun actualizarVE() {
        val nombre = contact_name_edit_text.text.toString()
        val numero = contact_phone_edit_text.text.toString()
        val propietario = user
        contacto = Contacto(nombreContacto = nombre, numeroTelefonico = numero, propietario = propietario)

    }

    private fun resetVE()
    {
        contact_name_edit_text.setText("");
        contact_phone_edit_text.setText("");
        btnGuardarContacto.text = "Save";
        /// ir a la vista MostrarListaContacto
        startActivity(Intent(this.applicationContext, MostrarListaContactoActivity::class.java))

    }

    @SuppressLint("SetTextI18n")
    fun cargarVE() {
        try {
            val intent = intent
            contacto = (intent.getSerializableExtra("contacto") as Contacto?)!!
            estado = intent.getIntExtra("estado", 0)
            contact_name_edit_text.setText(contacto.nombreContacto)
            contact_phone_edit_text.setText(contacto.numeroTelefonico)
            btnGuardarContacto.text = "Update"
            txtNewContact.text = "Update Contact"
        } catch (e: Exception) {
            estado = 0
        }
    }

    private fun verifyTextPersonName(editText: EditText): Boolean {
        if (editText.text.toString().isEmpty()){
            editText.error = "Required field"
            editText.requestFocus()
            return false
        } else if (!verifyChars(editText)) {
            editText.error = "Just letters are allowed"
            editText.requestFocus()
            return false
        }
        return true

    }

    fun verifyChars(editText: EditText): Boolean
    {
        //Validamos solo caracteres Expresion regular
//        Pattern.compile("^[a-zA-Z ]+$").matcher(editText.text.toString()).matches()

        return Pattern.compile("^[a-zA-Z ]+$").matcher(editText.text.toString()).matches()
    }
    fun verifyEmpty(editText: EditText): Boolean
    {
        if (editText.text.toString().isEmpty()){
            editText.error = "Required field"
            editText.requestFocus()
            return false
        }
        return true
    }

    // Se configura la flecha para salir de la actividad
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            android.R.id.home -> {
                // Finalizar la actividad
                finish()
            }
        }
        return super.onOptionsItemSelected(item)
    }
}