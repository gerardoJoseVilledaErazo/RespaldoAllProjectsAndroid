package com.muratozturk.orderfood.data.models

data class UserModel(
    val email: String?,
    val phoneNumber: String?,
)