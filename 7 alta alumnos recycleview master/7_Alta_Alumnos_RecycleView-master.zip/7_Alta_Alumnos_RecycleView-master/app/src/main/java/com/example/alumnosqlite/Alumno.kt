package com.example.alumnosqlite

data class Alumno (val noControl:String, val Nombre:String,val Carrera:String,val Edad:String)