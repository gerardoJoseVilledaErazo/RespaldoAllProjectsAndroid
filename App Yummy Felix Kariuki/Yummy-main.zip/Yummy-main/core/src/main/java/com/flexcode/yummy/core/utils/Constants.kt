package com.flexcode.yummy.core.utils

object Constants {
    const val BASE_URL = "https://www.themealdb.com/api/"
    const val DELAY_TIME = 500L
}
