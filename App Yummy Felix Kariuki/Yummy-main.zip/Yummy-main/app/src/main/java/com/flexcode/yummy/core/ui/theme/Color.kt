package com.flexcode.yummy.core.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF6200EE)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFF03DAC5)
val AntiFlashWhite = Color(0xFFF3F3F3)
val ColorGreen = Color(0xFF2DA231)
val Graffiti = Color(0xFF424952)
val Black = Color(0XFF28282B)
val MatteBlack = Color(0xFF171717)
val SurfaceOverlay = Color(0x7F000000)
