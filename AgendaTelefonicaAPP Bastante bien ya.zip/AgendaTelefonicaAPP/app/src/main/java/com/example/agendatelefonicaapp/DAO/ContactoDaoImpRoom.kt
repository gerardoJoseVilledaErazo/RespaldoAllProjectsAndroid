package com.example.agendatelefonicaapp.DAO

import android.content.Context
import androidx.room.Room
import com.example.agendatelefonicaapp.DataBase.ContactoDataBase
import com.example.agendatelefonicaapp.Models.Contacto

class ContactoDaoImpRoom (context: Context) : ContactoDAO
{
//    companion object {}
    val contactoDao: ContactoDAO = Room.databaseBuilder(
                            context,
    /*com.example.agendatelefonicaapp.DataBase.*/
                            ContactoDataBase::class.java,
                            "contacto.db"
                    ).allowMainThreadQueries()
                        .build().contactoDao()

//    /*private*/ var contactoDataBase: ContactoDataBase = Room.databaseBuilder(
//        context,
//        com.example.agendatelefonicaapp.DataBase.ContactoDataBase::class.java,
//        "contacto.db"
//    ).allowMainThreadQueries()
//        .build()
//    var contactoDao: ContactoDAO = contactoDataBase.contactoDao()

    override fun getAll(): MutableList<Contacto> = contactoDao.getAll()

    override fun get(id: Int): Contacto = contactoDao.get(id)

    override fun save(entity: Contacto) {
        contactoDao.save(entity)
    }

    override fun delete(entity: Contacto) {
        contactoDao.delete(entity)
    }

    override fun update(entity: Contacto) {
        contactoDao.update(entity)
    }
}