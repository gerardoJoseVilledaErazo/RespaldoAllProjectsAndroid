package com.example.agendatelefonicaapp

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.agendatelefonicaapp.Adapter.ContactoAdapter
import com.example.agendatelefonicaapp.DAO.ContactoDAO
import com.example.agendatelefonicaapp.DAO.ContactoDaoImpRoom
import com.example.agendatelefonicaapp.Models.Contacto
import com.example.agendatelefonicaapp.Provider.ContactoProvider.Companion.contactoList
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MostrarListaContactoActivity : AppCompatActivity() {

    companion object{
        var contactoVEList: MutableList<Contacto>? = null
    }
//    var contactoDaoVE: ContactoDAO? = null
//    var contactoDaoVE: ContactoDAO = ContactoDaoImpRoom(this.applicationContext)

    private lateinit var btnNuevoContacto: FloatingActionButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mostrar_lista_contacto)

        // Se agrega la flecha para salir de la actividad
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        // Se configura el nombre de la actividad
        title = "Mostrar Lista de Contactos"

        btnNuevoContacto = findViewById(R.id.btnNuevoContacto)

        btnNuevoContacto.setOnClickListener(){
            // Ir a Agregar contacto
            startActivity(Intent(this.applicationContext, AgregarContactoActivity::class.java))

        }

        // Cargando Datos
//        cargarDatosVE() //// esto se agrego recientemente

        this.initRecyclerView()
    }

    fun initRecyclerView(){
        val recyclerView = findViewById<RecyclerView>(R.id.rcvContacto)
        recyclerView.layoutManager = LinearLayoutManager(this)
//        recyclerView.adapter = contactoVEList?.let { ContactoAdapter(it,this) }
        recyclerView.adapter = ContactoAdapter(contactoList,this) /// este es el bueno******
    }

//    fun cargarDatosVE() {
//        contactoVEList = ArrayList<Contacto>()
//        contactoVEList = ContactoDaoImpRoom(this.applicationContext).getAll()
//    }

    // Se configura la flecha para salir de la actividad
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            android.R.id.home -> {
                // Finalizar la actividad
                finish()
            }
        }
        return super.onOptionsItemSelected(item)
    }
}