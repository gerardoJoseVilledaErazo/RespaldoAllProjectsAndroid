package com.example.agendatelefonicaapp.Adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.agendatelefonicaapp.AgregarContactoActivity
import com.example.agendatelefonicaapp.DAO.ContactoDAO
import com.example.agendatelefonicaapp.Models.Contacto
import com.example.agendatelefonicaapp.R

class ContactoAdapter(private var contactoList: MutableList<Contacto>
                        ,private val context: Context
//                        ,private val contactoDAO: ContactoDAO
                        ) : RecyclerView.Adapter<ContactoViewHolder>()
{
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactoViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        return ContactoViewHolder(layoutInflater.inflate(R.layout.item_contacto, parent, false))
    }

    override fun onBindViewHolder(holder: ContactoViewHolder, position: Int) {
        val item = contactoList[position]
        holder.render(item)

        holder.btnEliminar.setOnClickListener {
//            contactoDAO.delete(item)
//            contactoList = contactoDAO.getAll()
//            notifyDataSetChanged()
            eliminar(position)
            holder.render(item)
            Toast.makeText(context,"Deleted", Toast.LENGTH_SHORT).show();
        }

        holder.btnModificar.setOnClickListener { v->
            val agregarContacto = Intent(context, AgregarContactoActivity::class.java)
            agregarContacto.putExtra("estado",1) /// 1: Update
            agregarContacto.putExtra("contacto",item)
            v.context.startActivity(agregarContacto)

        }
    }

    override fun getItemCount(): Int = contactoList.size

    fun eliminar(position: Int){
        contactoList.removeAt(position)

    }
}